// Service worker do PS Gamepad — o mínimo necessário para o Chrome
// oferecer "Instalar app". Guarda em cache a página e os ícones, para
// abrir mesmo sem rede (a função de comando em si continua a precisar
// de Wi-Fi para falar com o PC).

const CACHE_VERSAO = 'ps-gamepad-v1';
const FICHEIROS_ESSENCIAIS = [
  './', './index.html', './manifest.json', './icon-192.png', './icon-512.png'
];

self.addEventListener('install', (evento) => {
  self.skipWaiting();
  evento.waitUntil(
    caches.open(CACHE_VERSAO).then((cache) =>
      Promise.all(FICHEIROS_ESSENCIAIS.map((f) => cache.add(f).catch(() => null)))
    )
  );
});

self.addEventListener('activate', (evento) => {
  self.clients.claim();
  evento.waitUntil(
    caches.keys().then((nomes) =>
      Promise.all(nomes.filter((n) => n !== CACHE_VERSAO).map((n) => caches.delete(n)))
    )
  );
});

self.addEventListener('fetch', (evento) => {
  const req = evento.request;
  if (req.method !== 'GET') return;
  evento.respondWith(
    caches.match(req).then((cached) => cached || fetch(req).catch(() => cached))
  );
});
