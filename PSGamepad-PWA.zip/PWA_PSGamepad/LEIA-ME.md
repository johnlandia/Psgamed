# PS Gamepad — versão "instalar como app" (igual à Dionuel)

Este é o mesmo formato que já usaste para a Dionuel: um site normal, com
`manifest.json` + `sw.js` + ícones, que o Chrome do Android oferece para
"Instalar app" — fica com ícone no ecrã inicial e abre em ecrã cheio, sem
barra de navegador. **Não precisa de GitHub, nem de compilar nada.**

## O que isto resolve — e o que continua na mesma

- ✅ Resolve: teres um "app" instalado no telemóvel, com ícone próprio,
  sem passar pelo GitHub Actions.
- ❌ Não resolve (nenhuma PWA resolve isto, nem a da Dionuel): acesso a
  Bluetooth para se registar como comando. Isso é bloqueado pelo próprio
  Android/Chrome para qualquer site, instalado ou não.

Por isso esta versão liga-se ao PC por **Wi-Fi** (como te expliquei antes),
não por Bluetooth. Precisas de correr o `server.py` (já tens, no
`PSGamepad-SemAPK.zip`) no PC quando quiseres jogar.

## Publicar no Netlify (mesmo processo que já fizeste na Dionuel)

1. Junta estes ficheiros todos na mesma pasta (já vêm juntos neste zip):
   `index.html`, `manifest.json`, `sw.js`, `icon-192.png`, `icon-512.png`,
   `_headers`
2. Compacta a pasta num `.zip`.
3. Vai a **app.netlify.com** → o site **ps-gamepad-install** (já existe na
   tua conta) → **"Deploys"** → **"Deploy manually"** → arrasta o `.zip`.
   (Ou usa app.netlify.com/drop se preferires um site novo.)
4. Abre o link do site no telemóvel. O Chrome deve mostrar, ao fim de
   alguns segundos, o aviso **"Instalar app"** (ou toca no menu ⋮ →
   "Instalar aplicação" / "Adicionar ao ecrã principal").

## Usar

1. No PC: corre `python server.py` (dentro da pasta `PSGamepadWiFi` que já
   tens) — ele mostra o IP do PC no terminal.
2. No telemóvel: abre o app instalado (ícone no ecrã inicial). No topo
   aparece uma caixa para escreveres o **IP do PC** — escreve o que
   apareceu no terminal (ex: `192.168.1.23`) e toca em "Ligar".
3. Assim que ligar, a caixa do IP desaparece e o comando fica pronto a
   usar. O telemóvel guarda esse IP, não precisas de o escrever outra vez
   (a não ser que mude).

## Nota

Isto e o `PSGamepad-projeto.zip` (o app Android "a sério", com Bluetooth
real) são dois caminhos diferentes para o mesmo objetivo. Esta versão PWA
é mais rápida de pôr a funcionar; a do GitHub dá Bluetooth verdadeiro mas
dá mais trabalho a gerar.
